Simple tutorial on how to install all nessesary assets to make the engine work:
1. Download Python SDK
2. Open Command bar
3. Enter these commands:
pip install pynput






Write your scripts in Instructions.
Check doc for guide on how to script in PEngine
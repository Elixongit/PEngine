import tkinter as tk
import ast, time, threading
from pynput import keyboard
window_size = "400x400"
game_name = "Unnamed Project"
background_color = "#ffffff"
window_icon = "Icon.ico"
label = None
UI_Label = None
game_vars = {}
event_vars = {}
input_vars = {}
def keys(key,command):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label
	if key == "game_name":
		command = command[1:]
		game_name = command
	elif key == "window_size":
		command = command[1:]
		window_size = command
	elif key == "background_color":
		command = command[1:]
		background_color = command
	elif key == "add_variable":
		game_vars[command[1]] = int(command[2])
	elif key == "add_event":
		event_vars[command[2]] = [command[1],command[3],command[4]]
	elif key == "input_event":
		input_vars[command[1]] = command[2]
	elif key == "add_label":
		if command[2] == "variable":
			label = [command[1],"var"]
		elif command[2] == "string":
			label = [command[1],"str"]

def events(evt,arr):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label
	if evt == "adder":
		result = game_vars[arr[1]] + game_vars[arr[2]]
		return result
	elif evt == "subtractor":
		result = game_vars[arr[1]] - game_vars[arr[2]]
		return result










def main():
	global UI_Label
	with open("Instructions.txt","r") as file:
		for line in file:
			line = line.strip()
			words = line.split()
			keys(words[0],words)
		window = tk.Tk()
		window.title(game_name)
		window.geometry(window_size)
		window.config(bg = background_color)
		window.iconbitmap(window_icon)
		thread = threading.Thread(target=update_label, daemon=True)
		thread.start()

		UI_Label = tk.Label(window, font=("Arial", 20),bg = background_color)
		UI_Label.pack(pady=20)
		window.mainloop()
		
def on_press(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	if str(k) in input_vars:
		evt = event_vars[input_vars[str(k)]]
		newvar = events(evt[0],evt)
		game_vars[evt[1]] = newvar
		print(game_vars[evt[1]])
def update_label():
	while True:
		time.sleep(.05)
		if label == None:
			pass
		else:
			if label[1] == "str":
				UI_Label.config(text = label[0])
			elif label[1] == "var":
				UI_Label.config(text = game_vars[label[0]])


listener = keyboard.Listener(on_press=on_press)
listener.start()


main()
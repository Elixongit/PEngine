import tkinter as tk
import ast, time, threading, math
from pynput import keyboard
window_size = "400x400"
game_name = "Unnamed Project"
background_color = "#ffffff"
window_icon = "Icon.ico"
event_cancel = False
w, h = map(int,window_size.split("x"))
label = None
label_default = ["Placeholder","str",w/2,"df",h/2,"df","20","str"]
circle_default = [w/2,"df",h/2,"df","50","str","50","str","#ffffff","str","#000000","str"]
label_data = {}
label_asset = {}
circle_data = {}
circle_asset = {}
canvas = None
label_size = [20,"integer"]
game_vars = {}
game_masks = {}
event_vars = {}
input_vars = {}




def keys(key,command):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label, label_size
	if key == "game_name":
		command = command[1:]
		game_name = command
	elif key == "window_size":
		command = command[1:]
		window_size = command
	elif key in ("background_color","bg_color"):
		command = command[1:]
		background_color = command
	elif key in ("add_variable","add_var"):
		val = None
		try:
			val = int(command[2])
		except ValueError:
			val = float(command[2])
		game_vars[command[1]] = val
	elif key == "add_mask":
		nm  =command[3:]
		var = masks(command[1],nm)
		game_masks[command[2]] = [var,command[1]] + command[3:]
	elif key == "add_event":
		if command[1] in ("adder","subtractor","multiplier","divider","exponetiator","add","sub","mul","div","pow"):
			event_vars[command[2]] = [command[1],command[3],command[4]]
		elif command[1] == "pulse":
			event_vars[command[2]] = [command[1]]+command[3:]
	elif key == "input_event":
		input_vars[command[1]] = command[2:]
	elif key == "add_label":
		label_data[command[1]] = command[2:] + label_default[len(command[2:]):]
		label_asset[command[1]] = canvas.create_text(int(w)/2,int(h)/2, font=("Arial", 20))
	elif key == "label_size":
		label_data[command[1]][6] = command[2]
		label_data[command[1]][7] = command[3]
	elif key == "add_circle":
		circle_data[command[1]] = command[2:] + circle_default[len(command[2:]):]
		circle_asset[command[1]] = canvas.create_oval(int(w)/2-50,int(h)/2-50,50+int(w)/2,50+int(w)/2, fill="#ffffff",outline="#000000")


def events(evt,arr):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label,event_cancel
	if evt in ("adder","add"):
		result = game_vars[arr[1]] + game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("subtractor","sub"):
		result = game_vars[arr[1]] - game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("multiplier","mul"):
		result = game_vars[arr[1]] * game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("divider","div" ):
		result = game_vars[arr[1]] / game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("exponetiator","pow"):
		result = game_vars[arr[1]] ** game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt == "pulse":
		pnum = game_vars[arr[1]]

		while game_vars[arr[1]] < game_vars[arr[2]]:
			
			
			time.sleep(game_vars[arr[4]])
			game_vars[arr[1]] += game_vars[arr[3]]
		while game_vars[arr[1]] > pnum:
			
			time.sleep(game_vars[arr[4]])
			game_vars[arr[1]] -= game_vars[arr[3]]
		event_cancel = False
		game_vars[arr[1]] = pnum

def masks(mask,num):
	if mask in ("sine","sin"):
		
		if len(num) > 1:	
			if len(num) > 2:
				if num[3] in ("str","string"):
					return math.sin(math.radians(game_vars[num[0]]))*float(num[1])+float(num[2])
				elif num[3] in ("var","variable"):
					return math.sin(math.radians(game_vars[num[0]]))*float(num[1])+float(game_vars[num[2]])
			else:
				return math.sin(math.radians(game_vars[num[0]]))*float(num[1])
		else:
			return math.sin(math.radians(game_vars[num[0]]))
			











def main():
	global UI_Label, canvas
	w, h = map(int,window_size.split("x"))
	window = tk.Tk()
	canvas = tk.Canvas(window,width = w,height = h,bg = background_color)
	with open("Instructions.txt","r") as file:
		for line in file:
			line = line.strip()
			words = line.split()
			keys(words[0],words)
		canvas.config(bg = background_color)
		window.title(game_name)
		window.geometry(window_size)
		window.config(bg = background_color)
		window.iconbitmap(window_icon)
		thread = threading.Thread(target=update_label, daemon=True)
		thread2 = threading.Thread(target=update_circle, daemon=True)
		thread3 = threading.Thread(target=update_mask, daemon=True)
		thread.start()
		thread2.start()
		thread3.start()
		w, h = map(int,window_size.split("x"))
		canvas.pack()

		
		window.mainloop()
		
def on_press(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label,event_cancel
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	if str(k) in input_vars:
		for ev in input_vars[str(k)]:
			evt = event_vars[ev]
			if event_cancel == False:
				if len(evt) > 5:
					if evt[5] == "true":
						event_cancel = True
					
				events(evt[0],evt)
def update_mask():
	global game_masks

	while True:
		time.sleep(0)
		for m in game_masks:
			nm = []+game_masks[m][2:]
			game_masks[m][0] = masks(game_masks[m][1],nm)
		
def update_label():
	global canvas
	while True:
		time.sleep(0)
		for k in label_data:
			x,y = canvas.coords(label_asset[k])
			if label_data[k][1] in ("string","str"):
				canvas.itemconfig(label_asset[k],text = label_data[k][0])
			elif label_data[k][1] in ("variable","var"):
				canvas.itemconfig(label_asset[k],text = game_vars[label_data[k][0]])
			elif label_data[k][1] in ("mask","msk"):
				canvas.itemconfig(label_asset[k],text = game_masks[label_data[k][0]][0])
			if label_data[k][3] in ("string","str"):
				canvas.coords(label_asset[k],int(label_data[k][2]),y)
			elif label_data[k][3] in ("variable","var"):
				canvas.coords(label_asset[k],game_vars[label_data[k][2]],y)
			elif label_data[k][3] in ("mask","msk"):
				canvas.coords(label_asset[k],game_maks[label_data[k][2]][0],y)
			x,y = canvas.coords(label_asset[k])
			if label_data[k][5] in ("string","str"):
				canvas.coords(label_asset[k],x,int(label_data[k][4]))
			elif label_data[k][5] in ("variable","var"):
				canvas.coords(label_asset[k],x,game_vars[label_data[k][4]])
			elif label_data[k][5] in ("mask","msk"):
				canvas.coords(label_asset[k],x,game_masks[label_data[k][4]][0])
			if label_data[k][7] in ("string","str"):
				canvas.itemconfig(label_asset[k],font = ("Arial",label_data[k][6]))
			elif label_data[k][7] in ("variable","var"):
				canvas.itemconfig(label_asset[k],font = ("Arial",game_vars[label_data[k][6]]))
			elif label_data[k][7] in ("mask","msk"):
				canvas.itemconfig(label_asset[k],font = ("Arial",game_masks[label_data[k][6]][0]))
def update_circle():
	global canvas
	while True:
		time.sleep(0)
		for k in circle_data:
			
			if circle_data[k][9] in ("string","str"):
				canvas.itemconfig(circle_asset[k],fill = circle_data[k][8])
			elif circle_data[k][9] in ("variable","var"):
				canvas.itemconfig(circle_asset[k],fill = game_vars[circle_data[k][8]])
			elif circle_data[k][9] in ("mask","msk"):
				canvas.itemconfig(circle_asset[k],fill = game_masks[circle_data[k][8]][0])
			rx = 0
			ry = 0

			if circle_data[k][5] in ("string","str"):
				rx = circle_data[k][4]
			elif circle_data[k][5] in ("variable","var"):
				rx = game_vars[circle_data[k][4]]
			elif circle_data[k][5] in ("mask","msk"):
				rx = game_masks[circle_data[k][4]][0]
			if circle_data[k][7] in ("string","str"):
				ry = circle_data[k][6]
			elif circle_data[k][7] in ("variable","var"):
				ry = game_vars[circle_data[k][6]]
			elif circle_data[k][7] in ("mask","msk"):
				ry = game_masks[circle_data[k][6]][0]


			x,y = 0,0
			if circle_data[k][1] in ("string","str"):
				x = circle_data[k][0]
			elif circle_data[k][1] in ("variable","var"):
				x = game_vars[circle_data[k][0]]
			elif circle_data[k][1] in ("masks","msk"):
				x = game_masks[circle_data[k][0]][0]
			if circle_data[k][3] in ("string","str"):
				y = circle_data[k][2]
			elif circle_data[k][3] in ("variable","var"):
				y = game_vars[circle_data[k][2]]
			elif circle_data[k][3] in ("masks","msk"):
				y = game_masks[circle_data[k][2]][0]
			canvas.coords(circle_asset[k],x-rx,y-ry,rx+x,ry+y)
			

			
			

def pre_press(key):
	threading.Thread(target = on_press,args=(key,)).start()
listener = keyboard.Listener(on_press=pre_press)
listener.start()


main()
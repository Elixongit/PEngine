import tkinter as tk
from pynput import keyboard
path = "Instructions.txt"
window_size = "400x400"
background_color = "#ffffff"
input_active = {}
points = []
def keys(key,command):
	global window_size
	if key == "window_size":
		window_size = command[1]

def click(event):
	if "p" in input_active:
		print(event.x,event.y)
		points.append(event.x)
		points.append(event.y)

def on_press(key):
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	input_active[k] = []

def on_release(key):
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	del input_active[k]
	if k == "p":
		with open(path,"a") as f:
			f.write("add_shape Poly\n")
			for point in range(0,len(points),2):
				f.write("add_shape_point Poly "+str(points[point])+" str "+str(points[point+1])+" str\n")


def main():
	global window
	w, h = map(int,window_size.split("x"))
	window = tk.Tk()
	canvas = tk.Canvas(window,width = w,height = h,bg = background_color)
	with open(path,"r") as f:
		for line in f:
			line = line.strip()
			words = line.split()
			keys(words[0],words)
		window.geometry(window_size)
		canvas.pack()
		canvas.bind("<Button-1>",click)
		window.mainloop()



listener = keyboard.Listener(on_press=on_press,on_release=on_release)
listener.start()

main()


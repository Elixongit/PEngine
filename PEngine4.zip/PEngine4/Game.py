import tkinter as tk
import ast, time, threading, math
from pynput import keyboard
fps_cap = 1000
ft = 1/fps_cap
window_size = "400x400"
window_split = window_size.split("x")
game_name = "Unnamed Project"
background_color = "#ffffff"
window_icon = "Icon.ico"
event_cancel = False
w, h = map(int,window_size.split("x"))
label = None
label_default = ["Placeholder","str",w/2,"df",h/2,"df","20","str"]
circle_default = [w/2,"df",h/2,"df","50","str","50","str","#ffffff","str","#000000","str"]
label_data = {}
label_asset = {}
circle_data = {}
circle_asset = {}
input_hold = {}
canvas = None
label_size = [20,"integer"]
game_vars = {}
game_masks = {}
game_arrs = {}
event_vars = {}
input_vars_press = {}
input_vars_release = {}
input_vars_hold = {}
input_active = {}


def track_frames():
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)




def keys(key,command):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_press,input_vars_release, window_icon, label, label_size,fps_cap,ft
	if key == "game_name":
		command = command[1:]
		game_name = command
	elif key == "window_size":
		command = command[1:]
		window_size = command
	elif key in ("frames_per_second","fps"):
		fps_cap = int(command[1])
		ft = 1/fps_cap
	elif key in ("background_color","bg_color"):
		command = command[1:]
		background_color = command
	elif key in ("add_variable","add_var"):
		val = None
		try:
			val = int(command[2])
		except ValueError:
			val = float(command[2])
		game_vars[command[1]] = val
	elif key in ("add_mask","add_msk"):
		nm  =command[3:]
		var = masks(command[1],nm)
		game_masks[command[2]] = [var,command[1]] + command[3:]
	elif key in ("add_array","add_arr"):
		if command[1] in ("manual","man"):
			game_arrs[command[2]] = ast.literal_eval(command[3])
	elif key == "add_event":
		if command[1] in ("adder","subtractor","multiplier","divider","exponetiator","add","sub","mul","div","pow","set"):
			event_vars[command[2]] = [command[1],command[3],command[4]]
		elif command[1] in ("pulse","pul","pulsen","puln","move","mov"):
			event_vars[command[2]] = [command[1]]+command[3:]
	elif key == "input_event":
		if command[1] in ("press","prs"):
			input_vars_press[command[2]] = command[3:]
		elif command[1] in ("release","rel"):
			input_vars_release[command[2]] = command[3:]
		elif command[1] in ("press_h","prsh"):
			input_vars_hold[command[2]] = command[3:]
	elif key == "add_label":
		label_data[command[1]] = command[2:] + label_default[len(command[2:]):]
		label_asset[command[1]] = canvas.create_text(int(w)/2,int(h)/2, font=("Arial", 20))
	elif key == "label_size":
		label_data[command[1]][6] = command[2]
		label_data[command[1]][7] = command[3]
	elif key == "add_circle":
		circle_data[command[1]] = command[2:] + circle_default[len(command[2:]):]


def events(evt,arr):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_press,input_vars_release, window_icon, label,event_cancel,game_masks
	if evt in ("adder","add"):
		result = game_vars[arr[1]] + game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("subtractor","sub"):
		result = game_vars[arr[1]] - game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("multiplier","mul"):
		result = game_vars[arr[1]] * game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("divider","div" ):
		result = game_vars[arr[1]] / game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("exponetiator","pow"):
		result = game_vars[arr[1]] ** game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("pulse","pul","pulsen","puln"):
		start_ = None
		end_ = None
		step_ = None
		delay_ = None
		if arr[2] in ("str","string"):
			start_ = [arr[1],"str"]
		elif arr[2] in ("var","variable"):
			start_ = [game_vars[arr[1]],"var"]
		elif arr[2] in ("msk","mask"):
			start_ = [game_masks[arr[1]][0],"msk"]
		if arr[4] in ("str","string"):
			end_ = [arr[3],"str"]
		elif arr[4] in ("var","variable"):
			end_ = [game_vars[arr[3]],"var"]
		elif arr[4] in ("msk","mask"):
			end_ = [game_masks[arr[3]][0],"msk"]
		if arr[6] in ("str","string"):
			step_ = [arr[5],"str"]
		elif arr[6] in ("var","variable"):
			step_ = [game_vars[arr[5]],"var"]
		elif arr[6] in ("msk","mask"):
			step_ = [game_masks[arr[5]][0],"msk"]
		if arr[8] in ("str","string"):
			delay_ = [arr[7],"str"]
		elif arr[8] in ("var","variable"):
			delay_ = [game_vars[arr[7]],"var"]
		elif arr[8] in ("msk","mask"):
			delay_ = [game_masks[arr[7]][0],"msk"]



		if evt in ("pulse","pul"):
			pnum = start_[0]

			while start_[0] < end_[0]:
				time.sleep(delay_[0])
				start_[0] += step_[0]
				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]
			while start_[0] > pnum:
				
				time.sleep(delay_[0])
				start_[0] -= step_[0]

				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]

			event_cancel = False
			start_[0] = pnum
		else:
			pnum = start_[0]

			
			while start_[0] > end_[0]:
				time.sleep(delay_[0])
				start_[0] -= step_[0]

				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]


			while start_[0] < pnum:
				time.sleep(delay_[0])
				start_[0] += step_[0]
				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]

			event_cancel = False
			start_[0] = pnum
	elif evt == "set":
		result = game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("move","mov"):
		pnum = game_vars[arr[1]]

		while game_vars[arr[1]] < game_vars[arr[2]]:
			
			
			time.sleep(game_vars[arr[4]])
			game_vars[arr[1]] += game_vars[arr[3]]
		game_vars[arr[1]] = pnum

def masks(mask,num):
	if mask in ("sine","sin"):
		
		if len(num) > 1:	
			if len(num) > 2:
				if num[3] in ("str","string"):
					return math.sin(math.radians(game_vars[num[0]]))*float(num[1])+float(num[2])
				elif num[3] in ("var","variable"):
					return math.sin(math.radians(game_vars[num[0]]))*float(num[1])+float(game_vars[num[2]])
			else:
				return math.sin(math.radians(game_vars[num[0]]))*float(num[1])
		else:
			return math.sin(math.radians(game_vars[num[0]]))
	elif mask in ("offset","ofs"):
		if num[2] in ("str","string"):
			return game_vars[num[0]] + int(num[1])
		elif num[2] in ("variable","var"):
			return game_vars[num[0]] + game_vars[num[1]]











def main():
	global UI_Label, canvas
	w, h = map(int,window_size.split("x"))
	window = tk.Tk()
	canvas = tk.Canvas(window,width = w,height = h,bg = background_color)
	with open("Instructions.txt","r") as file:
		for line in file:

			line = line.strip()
			words = line.split()
			keys(words[0],words)
			
		canvas.config(bg = background_color)
		window.title(game_name)
		window.geometry(window_size)
		window.config(bg = background_color)
		window.iconbitmap(window_icon)
		thread = threading.Thread(target=update_label, daemon=True)
		thread2 = threading.Thread(target=update_circle, daemon=True)
		thread3 = threading.Thread(target=update_mask, daemon=True)
		thread4 = threading.Thread(target=press_hold, daemon=True)
		thread5 = threading.Thread(target=track_frames, daemon=True)
		thread.start()
		thread2.start()
		thread3.start()
		thread4.start()
		thread5.start()
		w, h = map(int,window_size.split("x"))
		canvas.pack()

		
		window.mainloop()
		
def on_press(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_press, window_icon, label,event_cancel
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	input_hold[k] = None
	if str(k) in input_vars_press:
		for ev in input_vars_press[str(k)]:
			evt = event_vars[ev]
			if len(evt) > 9:
				if evt[9] == "true":
					threading.Thread(target=events, args=(evt[0], evt), daemon=True).start()
				else:
					events(evt[0],evt)
			else:
				events(evt[0],evt)


				
def press_hold():
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_hold, window_icon, label,event_cancel
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in input_vars_hold:
			input_hold[k] = None
			if str(k) in input_active:
				for ev in input_vars_hold[str(k)]:
					evt = event_vars[ev]
					if event_cancel == False:
						if len(evt) > 5:
							if evt[5] == "true":
								event_cancel = True
						events(evt[0],evt)
def on_release(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_release, window_icon, label,event_cancel
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	del input_hold[k]
	if str(k) in input_vars_release:
		for ev in input_vars_release[str(k)]:
			evt = event_vars[ev]
			if event_cancel == False:
				if len(evt) > 5:
					if evt[5] == "true":
						event_cancel = True
				events(evt[0],evt)
def update_mask():
	global game_masks
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for m in game_masks:
			nm = []+game_masks[m][2:]
			game_masks[m][0] = masks(game_masks[m][1],nm)
		
def update_label():
	global canvas
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in label_data:
			x,y = canvas.coords(label_asset[k])
			if label_data[k][1] in ("string","str"):
				canvas.itemconfig(label_asset[k],text = label_data[k][0])
			elif label_data[k][1] in ("variable","var"):
				canvas.itemconfig(label_asset[k],text = game_vars[label_data[k][0]])
			elif label_data[k][1] in ("mask","msk"):
				canvas.itemconfig(label_asset[k],text = game_masks[label_data[k][0]][0])
			if label_data[k][3] in ("string","str"):
				canvas.coords(label_asset[k],int(label_data[k][2]),y)
			elif label_data[k][3] in ("variable","var"):
				canvas.coords(label_asset[k],game_vars[label_data[k][2]],y)
			elif label_data[k][3] in ("mask","msk"):
				canvas.coords(label_asset[k],game_masks[label_data[k][2]][0],y)
			x,y = canvas.coords(label_asset[k])
			if label_data[k][5] in ("string","str"):
				canvas.coords(label_asset[k],x,int(label_data[k][4]))
			elif label_data[k][5] in ("variable","var"):
				canvas.coords(label_asset[k],x,game_vars[label_data[k][4]])
			elif label_data[k][5] in ("mask","msk"):
				canvas.coords(label_asset[k],x,game_masks[label_data[k][4]][0])
			if label_data[k][7] in ("string","str"):
				canvas.itemconfig(label_asset[k],font = ("Arial",label_data[k][6]))
			elif label_data[k][7] in ("variable","var"):
				canvas.itemconfig(label_asset[k],font = ("Arial",game_vars[label_data[k][6]]))
			elif label_data[k][7] in ("mask","msk"):
				canvas.itemconfig(label_asset[k],font = ("Arial",game_masks[label_data[k][6]][0]))
def update_circle():
	global canvas,circle_data,circle_asset
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in list(circle_data.keys()):
			if k not in circle_asset:
				circle_asset[k] = canvas.create_oval(int(w)/2-50,int(h)/2-50,50+int(w)/2,50+int(w)/2, fill="#ffffff",outline="#000000")
			if circle_data[k][9] in ("string","str"):
				canvas.itemconfig(circle_asset[k],fill = circle_data[k][8])
			elif circle_data[k][9] in ("variable","var"):
				canvas.itemconfig(circle_asset[k],fill = game_vars[circle_data[k][8]])
			elif circle_data[k][9] in ("mask","msk"):
				canvas.itemconfig(circle_asset[k],fill = game_masks[circle_data[k][8]][0])
			rx = 0
			ry = 0

			if circle_data[k][5] in ("string","str"):
				rx = circle_data[k][4]
			elif circle_data[k][5] in ("variable","var"):
				rx = game_vars[circle_data[k][4]]
			elif circle_data[k][5] in ("mask","msk"):
				rx = game_masks[circle_data[k][4]][0]
			if circle_data[k][7] in ("string","str"):
				ry = circle_data[k][6]
			elif circle_data[k][7] in ("variable","var"):
				ry = game_vars[circle_data[k][6]]
			elif circle_data[k][7] in ("mask","msk"):
				ry = game_masks[circle_data[k][6]][0]


			x,y = 0,0
			arrx, arry  = False, False
			if circle_data[k][1] in ("string","str"):
				x = circle_data[k][0]
			elif circle_data[k][1] in ("variable","var"):
				x = game_vars[circle_data[k][0]]
			elif circle_data[k][1] in ("mask","msk"):
				x = game_masks[circle_data[k][0]][0]
			elif circle_data[k][1] in ("array","arr"):
				x = game_arrs[circle_data[k][0]]
				arrx = True
			if circle_data[k][3] in ("string","str"):
				y = circle_data[k][2]
			elif circle_data[k][3] in ("variable","var"):
				y = game_vars[circle_data[k][2]]
			elif circle_data[k][3] in ("masks","msk"):
				y = game_masks[circle_data[k][2]][0]
			elif circle_data[k][3] in ("array","arr"):
				y = game_arrs[circle_data[k][0]]
				arry = True
			if arrx == False and arry == False:
				canvas.coords(circle_asset[k], x-rx, y-ry, x+rx, y+ry)
			else:
				if not isinstance(x, list):
					x = [x] * len(y)
				if not isinstance(y, list):
					y = [y] * len(x)
			    
				for nmb in range(len(x)):
					ox = x[nmb] - rx
					oy = y[nmb] - ry
					ox2 = x[nmb] + rx
					oy2 = y[nmb] + ry
					circle_name = f"{k}_{nmb}" if nmb > 0 else k
					if circle_name not in circle_asset:
						circle_asset[circle_name] = canvas.create_oval(ox, oy, ox2, oy2, fill=circle_data[k][8])
					else:
						canvas.coords(circle_asset[circle_name], ox, oy, ox2, oy2)




			

			
			

def pre_press(key):

	try:
		k = key.char
	except AttributeError:
		k = str(key)
	input_active[k] = []

	threading.Thread(target = on_press,args=(key,)).start()
def pre_release(key):

	try:
		k = key.char
	except AttributeError:
		k = str(key)
	del input_active[k]

	threading.Thread(target = on_release,args=(key,)).start()

listener = keyboard.Listener(on_press=pre_press,on_release=pre_release)
listener.start()


main()
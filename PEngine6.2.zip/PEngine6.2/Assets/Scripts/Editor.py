import tkinter as tk
from pynput import keyboard
import threading
path = "Instructions.txt"
window_size = ["400x400","str"]
background_color = "#ffffff"

input_active = {}
points = []
temp_shapes = []
closing_line = None
canvas = None
window = None

def sleep():
    start = time.time()
    elapsed = time.time() - start
    sleep_time = ft - elapsed
    if sleep_time > 0:
        time.sleep(sleep_time)

def keys(key,arr):
    global window_size
    if key == "window_size":
        if arr[2] == "str":
            print(arr[1])
            window_size = arr[1:]

def click(event):
    global points, temp_shapes, closing_line, canvas
    if "p" in input_active:
        points.append(event.x)
        points.append(event.y)
        dot = canvas.create_oval(event.x - 3, event.y - 3,
                                 event.x + 3, event.y + 3,
                                 fill="red", outline="")
        temp_shapes.append(dot)
        if len(points) >= 4:
            x1, y1 = points[-4], points[-3]
            x2, y2 = points[-2], points[-1]
            line = canvas.create_line(x1, y1, x2, y2, fill="blue")
            temp_shapes.append(line)
        if len(points) >= 4:
            x_last, y_last = points[-2], points[-1]
            x_first, y_first = points[0], points[1]
            if closing_line is None:
                closing_line = canvas.create_line(x_last, y_last, x_first, y_first,
                                                  fill="blue", dash=(4, 4))
                temp_shapes.append(closing_line)
            else:
                canvas.coords(closing_line, x_last, y_last, x_first, y_first)
        elif len(points) == 2:
            if closing_line is None:
                closing_line = canvas.create_line(points[0], points[1],
                                                  points[0], points[1],
                                                  fill="blue", dash=(4, 4))
                temp_shapes.append(closing_line)
            else:
                canvas.coords(closing_line, points[0], points[1], points[0], points[1])

def on_press(key):
    try:
        k = key.char
    except AttributeError:
        k = str(key)
    input_active[k] = []

def on_release(key):
    try:
        k = key.char
    except AttributeError:
        k = str(key)
    input_active.pop(k, None)
    if k == "p" and points:
        def finalize_polygon():
            global points, temp_shapes, closing_line, canvas, window
            if len(points) >= 4:
                x_last, y_last = points[-2], points[-1]
                x_first, y_first = points[0], points[1]
                if closing_line is None:
                    cl = canvas.create_line(x_last, y_last, x_first, y_first,
                                            fill="blue", dash=(4, 4))
                    temp_shapes.append(cl)
                else:
                    canvas.coords(closing_line, x_last, y_last, x_first, y_first)
            try:
                with open(path, "a") as f:
                    f.write("add_shape Poly\n")
                    for i in range(0, len(points), 2):
                        f.write(f"add_shape_point Poly {points[i]} str {points[i+1]} str\n")
            except Exception as e:
                print("Failed to write shape:", e)
            def clear_temp():
                global points, temp_shapes, closing_line
                for item in temp_shapes:
                    try:
                        canvas.delete(item)
                    except Exception:
                        pass
                temp_shapes.clear()
                points.clear()
                closing_line = None
            window.after(200, clear_temp)
        if canvas:
            canvas.after(0, finalize_polygon)

def main():
    global window,canvas
    window = tk.Tk()
    canvas = tk.Canvas(bg = background_color)
    with open(path,"r") as f:
        for line in f:
            line = line.strip()
            words = line.split()
            keys(words[0],words)
        canvas.pack()
        canvas.bind("<Button-1>",click)
    window.geometry(window_size[0])
    w, h = map(int,window_size[0].split("x"))
    canvas.config(width=w,height=h)
    window.mainloop()
    threading.Thread(target=update_window,daemon= True).start()

listener = keyboard.Listener(on_press=on_press, on_release=on_release)
listener.start()

main()

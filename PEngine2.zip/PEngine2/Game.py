import tkinter as tk
import ast, time, threading
from pynput import keyboard
window_size = "400x400"
game_name = "Unnamed Project"
background_color = "#ffffff"
window_icon = "Icon.ico"
event_cancel = False
label = None
UI_Label = None
label_size = [20,"integer"]
game_vars = {}
event_vars = {}
input_vars = {}




def keys(key,command):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label, label_size
	if key == "game_name":
		command = command[1:]
		game_name = command
	elif key == "window_size":
		command = command[1:]
		window_size = command
	elif key in ("background_color","bg_color"):
		command = command[1:]
		background_color = command
	elif key in ("add_variable","add_var"):
		val = None
		try:
			val = int(command[2])
		except ValueError:
			val = float(command[2])
		game_vars[command[1]] = val
	elif key == "add_event":
		if command[1] in ("adder","subtractor","multiplier","divider","exponetiator","add","sub","mul","div","pow"):
			event_vars[command[2]] = [command[1],command[3],command[4]]
		elif command[1] == "pulse":
			event_vars[command[2]] = [command[1]]+command[3:]
	elif key == "input_event":
		input_vars[command[1]] = command[2:]
	elif key == "add_label":
		if command[2] in ("variable","var"):
			label = [command[1],"var"]
		elif command[2] in ("string","str"):
			label = [command[1],"str"]
	elif key == "label_size":
		label_size = [command[1],command[2]]

def events(evt,arr):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label,event_cancel
	if evt in ("adder","add"):
		result = game_vars[arr[1]] + game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("subtractor","sub"):
		result = game_vars[arr[1]] - game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("multiplier","mul"):
		result = game_vars[arr[1]] * game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("divider","div" )
		result = game_vars[arr[1]] / game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("exponetiator","pow"):
		result = game_vars[arr[1]] ** game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt == "pulse":
		pnum = game_vars[arr[1]]

		while game_vars[arr[1]] < game_vars[arr[2]]:
			
			
			time.sleep(game_vars[arr[4]])
			game_vars[arr[1]] += game_vars[arr[3]]
		while game_vars[arr[1]] > pnum:
			
			time.sleep(game_vars[arr[4]])
			game_vars[arr[1]] -= game_vars[arr[3]]
		event_cancel = False
		game_vars[arr[1]] = pnum













def main():
	global UI_Label
	with open("Instructions.txt","r") as file:
		for line in file:
			line = line.strip()
			words = line.split()
			keys(words[0],words)
		window = tk.Tk()
		window.title(game_name)
		window.geometry(window_size)
		window.config(bg = background_color)
		window.iconbitmap(window_icon)
		thread = threading.Thread(target=update_label, daemon=True)
		thread.start()

		UI_Label = tk.Label(window, font=("Arial", 20),bg = background_color)
		UI_Label.pack(pady=20)
		window.mainloop()
		
def on_press(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars, window_icon, label,event_cancel
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	if str(k) in input_vars:
		for ev in input_vars[str(k)]:
			evt = event_vars[ev]
			if event_cancel == False:
				if len(evt) > 5:
					if evt[5] == "true":
						event_cancel = True
					
				events(evt[0],evt)
		
def update_label():
	while True:
		time.sleep(.05)
		if label == None:
			pass
		else:
			if label[1] == "str":
				UI_Label.config(text = label[0])
			elif label[1] == "var":
				UI_Label.config(text = game_vars[label[0]])
		if label_size[1] == "integer":
			UI_Label.config(font = ("Arial",int(label_size[0])))
		elif label_size[1] == "variable":
			sz = game_vars[label_size[0]]
			UI_Label.config(font = ("Arial",sz))

def pre_press(key):
	threading.Thread(target = on_press,args=(key,)).start()
listener = keyboard.Listener(on_press=pre_press)
listener.start()


main()
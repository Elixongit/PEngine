import tkinter as tk
import ast, time, threading, math
from pynput import keyboard
fps_cap = 1000
ft = 1/fps_cap
window_size = "400x400"
window_split = window_size.split("x")
game_name = "Unnamed Project"
background_color = "#ffffff"
window_icon = "Icon.ico"
event_cancel = False
w, h = map(int,window_size.split("x"))
label = None
label_default = ["Placeholder","str",w/2,"df",h/2,"df","20","str"]
circle_default = [w/2,"df",h/2,"df","50","str","50","str","#ffffff","str","#000000","str"]
square_default = ["50","str","50","str","150","str","150","str","#ffffff","str","#000000","str"]
shape_config_default = ["0","str","#ffffff","str","#000000","str","0.3","str","0","str","0","str"]
shape_config_default_points = [0,0,0,0,0,0]
label_data = {}
label_asset = {}
circle_data = {}
square_data = {}
shape_data = {}
circle_asset = {}
square_asset = {}
shape_asset = {}
shape_config = {}
input_hold = {}
canvas = None
label_size = [20,"integer"]
game_vars = {}
game_masks = {}
game_arrs = {}
game_conditions = {}
event_vars = {}
input_vars_press = {}
input_vars_release = {}
input_vars_hold = {}
input_active = {}
condition_events = {}


def track_frames():
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)




def keys(key,command):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_press,input_vars_release, window_icon, label, label_size,fps_cap,ft,game_conditions,condition_events,shape_config
	if key == "game_name":
		command = command[1:]
		game_name = command
	elif key == "window_size":
		command = command[1:]
		window_size = command
	elif key in ("frames_per_second","fps"):
		fps_cap = int(command[1])
		ft = 1/fps_cap
	elif key in ("background_color","bg_color"):
		command = command[1:]
		background_color = command
	elif key in ("add_variable","add_var"):
		val = None
		try:
			val = int(command[2])
		except ValueError:
			try:
				val = float(command[2])
			except ValueError:
				val = command[2:]
		game_vars[command[1]] = val
	elif key in ("add_mask","add_msk"):
		nm  =command[3:]
		var = masks(command[1],nm)
		game_masks[command[2]] = [var,command[1]] + command[3:]
	elif key in ("add_array","add_arr"):
		if command[1] in ("manual","man"):
			game_arrs[command[2]] = ast.literal_eval(command[3])
	elif key == "add_event":
		if command[1] in ("multiplier","divider","exponetiator","mul","div","pow"):
			event_vars[command[2]] = [command[1],command[3],command[4]]
		elif command[1] in ("pulse","pul","pulsen","puln","move","mov","set","adder","add","subtractor","sub","moven","movn"):
			event_vars[command[2]] = [command[1]]+command[3:]
		elif command[1] in ("debug","bug"):
			event_vars[command[2]] = [command[1],command[3],command[4]]
	elif key == "input_event":
		if command[1] in ("press","prs"):
			input_vars_press[command[2]] = command[3:]
		elif command[1] in ("release","rel"):
			input_vars_release[command[2]] = command[3:]
		elif command[1] in ("press_h","prsh"):
			input_vars_hold[command[2]] = command[3:]
	elif key == "add_label":
		label_data[command[1]] = command[2:] + label_default[len(command[2:]):]
	elif key == "label_size":
		label_data[command[1]][6] = command[2]
		label_data[command[1]][7] = command[3]
	elif key == "add_circle":
		circle_data[command[1]] = command[2:] + circle_default[len(command[2:]):]
	elif key == "add_square":
		square_data[command[1]] = command[2:] + square_default[len(command[2:]):]
	elif key == "add_shape":
		shape_data[command[1]] = []
		shape_config[command[1]] = shape_config_default.copy()
	elif key == "add_shape_point":
		shape_data[command[1]].extend(command[2:])
	elif key == "add_shape_color":
		shape_config[command[1]][2] = command[2]
		shape_config[command[1]][3] = command[3]
	elif key == "add_shape_outline_color":
		shape_config[command[1]][4] = command[2]
		shape_config[command[1]][5] = command[3]
	elif key == "add_shape_outline":
		shape_config[command[1]][6] = command[2]
		shape_config[command[1]][7] = command[3]
	elif key == "add_shape_rotation":
		shape_config[command[1]][0] = command[2]
		shape_config[command[1]][1] = command[3]
	elif key == "add_shape_pivot":
		shape_config[command[1]][8] = command[2]
		shape_config[command[1]][9] = command[3]
		shape_config[command[1]][10] = command[4]
		shape_config[command[1]][11] = command[5]
	elif key in ("add_con","add_condition"):
		game_conditions[command[2]] = [command[1]]+command[3:]
	elif key in ("conditional_event","con_event"):
		condition_events[command[1]] = [command[2]]+command[3:]

def conditions(con,arr):
	num1 = arr[1]
	num2 = arr[3]
	if arr[2] == "str":
		num1 = int[arr[1]]
	elif arr[2] == "var":
		num1 = game_vars[arr[1]]
	elif arr[2] == "msk":
		num1 = game_masks[arr[1]][0]
	if arr[4] == "str":
		num2 = int(arr[3])
	elif arr[4] == "var":
		num2 = game_vars[arr[3]]
	elif arr[4] == "msk":
		num2 = game_masks[arr[3]][0]
	if con in ("=","equal"):
		if num1 == num2:
			return True
		else:
			return False
	elif con in(">","bigger"):
		if num1 > num2:
			return True
		else:
			return False
	elif con in ("<","smaller"):
		if num1 < num2:
			return True
		else:
			return False

def events(evt,arr):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_press,input_vars_release, window_icon, label,event_cancel,game_masks
	if evt in ("adder","add"):
		if arr[3] in ("var","variable"):
			result = game_vars[arr[1]] + game_vars[arr[2]]
			game_vars[arr[1]] = result
		elif arr[3] in ("mask","msk"):
			result = game_vars[arr[1]] + game_masks[arr[2]][0]
			game_vars[arr[1]] = result
		elif arr[3] in ("str","string"):
			var = None
			try:
				var = float(arr[2])
			except ValueError:
				var = int(arr[2])
			result = game_vars[arr[1]] + var
			game_vars[arr[1]] = result

	elif evt in ("subtractor","sub"):
		if arr[3] in ("var","variable"):
			result = game_vars[arr[1]] - game_vars[arr[2]]
			game_vars[arr[1]] = result
		elif arr[3] in ("mask","msk"):
			result = game_vars[arr[1]] - game_masks[arr[2]][0]
			game_vars[arr[1]] = result
		elif arr[3] in ("str","string"):
			var = None
			try:
				var = float(arr[2])
			except ValueError:
				var = int(arr[2])
			result = game_vars[arr[1]] - var
			game_vars[arr[1]] = result
	elif evt in ("multiplier","mul"):
		result = game_vars[arr[1]] * game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("divider","div" ):
		result = game_vars[arr[1]] / game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("exponetiator","pow"):
		result = game_vars[arr[1]] ** game_vars[arr[2]]
		game_vars[arr[1]] = result
	elif evt in ("pulse","pul","pulsen","puln"):
		start_ = None
		end_ = None
		step_ = None
		delay_ = None
		if arr[2] in ("str","string"):
			start_ = [arr[1],"str"]
		elif arr[2] in ("var","variable"):
			start_ = [game_vars[arr[1]],"var"]
		elif arr[2] in ("msk","mask"):
			start_ = [game_masks[arr[1]][0],"msk"]
		if arr[4] in ("str","string"):
			end_ = [arr[3],"str"]
		elif arr[4] in ("var","variable"):
			end_ = [game_vars[arr[3]],"var"]
		elif arr[4] in ("msk","mask"):
			end_ = [game_masks[arr[3]][0],"msk"]
		if arr[6] in ("str","string"):
			step_ = [arr[5],"str"]
		elif arr[6] in ("var","variable"):
			step_ = [game_vars[arr[5]],"var"]
		elif arr[6] in ("msk","mask"):
			step_ = [game_masks[arr[5]][0],"msk"]
		if arr[8] in ("str","string"):
			delay_ = [arr[7],"str"]
		elif arr[8] in ("var","variable"):
			delay_ = [game_vars[arr[7]],"var"]
		elif arr[8] in ("msk","mask"):
			delay_ = [game_masks[arr[7]][0],"msk"]



		if evt in ("pulse","pul"):
			pnum = start_[0]

			while start_[0] < end_[0]:
				time.sleep(delay_[0])
				start_[0] += step_[0]
				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]
			while start_[0] > pnum:
				
				time.sleep(delay_[0])
				start_[0] -= step_[0]

				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]

			event_cancel = False
			start_[0] = pnum
		else:
			pnum = start_[0]

			
			while start_[0] > end_[0]:
				time.sleep(delay_[0])
				start_[0] -= step_[0]

				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]


			while start_[0] < pnum:
				time.sleep(delay_[0])
				start_[0] += step_[0]
				if start_[1] == "var":
					game_vars[arr[1]] = start_[0]
				elif start_[1] == "msk":
					game_masks[arr[1]][0] = start_[0]

			event_cancel = False
			start_[0] = pnum
	elif evt == "set":
		if arr[3] in ("var","variable"):
			result = game_vars[arr[2]]
			game_vars[arr[1]] = result
		elif arr[3] in ("str","string"):
			result = None
			try:
				result = float(arr[2])
			except ValueError:
				try:
					result = int(arr[2])
				except ValueError:
					result = arr[2]
			game_vars[arr[1]] = result
	elif evt in ("move","mov"):

		start_ = None
		end_ = None
		step_ = None
		delay_ = None
		if arr[2] in ("str","string"):
			start_ = [arr[1],"str"]
		elif arr[2] in ("var","variable"):
			start_ = [game_vars[arr[1]],"var"]
		elif arr[2] in ("msk","mask"):
			start_ = [game_masks[arr[1]][0],"msk"]
		if arr[4] in ("str","string"):
			end_ = [arr[3],"str"]
		elif arr[4] in ("var","variable"):
			end_ = [game_vars[arr[3]],"var"]
		elif arr[4] in ("msk","mask"):
			end_ = [game_masks[arr[3]][0],"msk"]
		if arr[6] in ("str","string"):
			step_ = [arr[5],"str"]
		elif arr[6] in ("var","variable"):
			step_ = [game_vars[arr[5]],"var"]
		elif arr[6] in ("msk","mask"):
			step_ = [game_masks[arr[5]][0],"msk"]
		if arr[8] in ("str","string"):
			delay_ = [arr[7],"str"]
		elif arr[8] in ("var","variable"):
			delay_ = [game_vars[arr[7]],"var"]
		elif arr[8] in ("msk","mask"):
			delay_ = [game_masks[arr[7]][0],"msk"]


		pnum = end_[0]

		while start_[0] < end_[0]:
			
			
			time.sleep(delay_[0])
			start_[0] += step_[0]

			if start_[1] == "var":
				game_vars[arr[1]] = start_[0]
			elif start_[1] == "msk":
				game_masks[arr[1]][0] = start_[0]
		game_vars[arr[1]] = pnum
	elif evt in ("moven","movn"):
		start_ = None
		end_ = None
		step_ = None
		delay_ = None
		if arr[2] in ("str","string"):
			start_ = [arr[1],"str"]
		elif arr[2] in ("var","variable"):
			start_ = [game_vars[arr[1]],"var"]
		elif arr[2] in ("msk","mask"):
			start_ = [game_masks[arr[1]][0],"msk"]
		if arr[4] in ("str","string"):
			end_ = [arr[3],"str"]
		elif arr[4] in ("var","variable"):
			end_ = [game_vars[arr[3]],"var"]
		elif arr[4] in ("msk","mask"):
			end_ = [game_masks[arr[3]][0],"msk"]
		if arr[6] in ("str","string"):
			step_ = [arr[5],"str"]
		elif arr[6] in ("var","variable"):
			step_ = [game_vars[arr[5]],"var"]
		elif arr[6] in ("msk","mask"):
			step_ = [game_masks[arr[5]][0],"msk"]
		if arr[8] in ("str","string"):
			delay_ = [arr[7],"str"]
		elif arr[8] in ("var","variable"):
			delay_ = [game_vars[arr[7]],"var"]
		elif arr[8] in ("msk","mask"):
			delay_ = [game_masks[arr[7]][0],"msk"]


		pnum = end_[0]

		while start_[0] > end_[0]:
			
			
			time.sleep(delay_[0])
			start_[0] -= step_[0]

			if start_[1] == "var":
				game_vars[arr[1]] = start_[0]
			elif start_[1] == "msk":
				game_masks[arr[1]][0] = start_[0]
		game_vars[arr[1]] = pnum
	elif evt in ("debug","bug"):
		if arr[2] in ("var","variable"):
			print(game_vars[arr[1]])
		elif arr[2] in ("mask","msk"):
			print(game_masks[arr[1]][0])
		elif arr[2] in ("str","string"):
			print(arr[1])

def masks(mask,num):
	if mask in ("sine","sin"):
		
		if len(num) > 1:	
			if len(num) > 2:
				if num[3] in ("str","string"):
					return math.sin(math.radians(game_vars[num[0]]))*float(num[1])+float(num[2])
				elif num[3] in ("var","variable"):
					return math.sin(math.radians(game_vars[num[0]]))*float(num[1])+float(game_vars[num[2]])
			else:
				return math.sin(math.radians(game_vars[num[0]]))*float(num[1])
		else:
			return math.sin(math.radians(game_vars[num[0]]))
	elif mask in ("offset","ofs"):
		if num[2] in ("str","string"):
			return game_vars[num[0]] + int(num[1])
		elif num[2] in ("variable","var"):
			return game_vars[num[0]] + game_vars[num[1]]
		elif num[2] in ("mask","msk"):
			return game_vars[num[0]] + game_masks[num[1]][0]
	elif mask in ("distance","dis"):
		pos1 = None
		pos2 = None
		pos3 = None
		pos4 = None

		if num[1] in ("str","string"):
			pos1 = num[0]
		elif num[1] in ("var","variable"):
			pos1 = game_vars[num[0]]
		elif num[1] in ("msk","mask"):
			pos1 = game_masks[num[0]][0]
		if num[3] in ("str","string"):
			pos2 = num[2]
		elif num[3] in ("var","variable"):
			pos2 = game_vars[num[2]]
		elif num[3] in ("msk","mask"):
			pos2 = game_masks[num[2]][0]
		if num[5] in ("str","string"):
			pos3 = num[4]
		elif num[5] in ("var","variable"):
			pos3 = game_vars[num[4]]
		elif num[5] in ("msk","mask"):
			pos3 = game_masks[num[4]][0]
		if num[7] in ("str","string"):
			pos4 = num[6]
		elif num[7] in ("var","variable"):
			pos4 = game_vars[num[6]]
		elif num[7] in ("msk","mask"):
			pos4 = game_masks[num[6]][0]

		return math.dist((pos1,pos2),(pos3,pos4))
	elif mask in ("swap","swp"):
		
		if num[1] in ("var","varable"):
			if game_vars[num[0]] > 0:
				return -game_vars[num[0]]
			else:
				return abs(game_vars[num[0]])
		elif num[1] in ("mask","msk"):
			if game_masks[num[0]][0] > 0:
				return -game_masks[num[0]][0]
			else:
				return abs(game_masks[num[0]][0])
	elif mask in ("divide","div"):
		num0 = None
		num1 = None

		if num[1] in ("var","variable"):
			num0 = game_vars[num[0]]
		elif num[1] in ("msk","mask"):
			num0 = game_masks[num[0]][0]
		if num[3] in ("var","variable"):
			num1 = game_vars[num[2]]
		elif num[3] in ("msk","mask"):
			num1 = game_masks[num[2]][0]
		return num0 / num1


		
			












def main():
	global UI_Label, canvas
	w, h = map(int,window_size.split("x"))
	window = tk.Tk()
	canvas = tk.Canvas(window,width = w,height = h,bg = background_color)
	with open("Instructions.txt","r") as file:
		for line in file:

			line = line.strip()
			words = line.split()
			keys(words[0],words)
			if words[0] == "add_circle":
				update_circle("no")
			elif words[0] == "add_label":
				update_label("no")
			elif words[0] == "add_square":
				update_square("no")
			elif words[0] == "add_shape":
				update_shape("no")
		canvas.config(bg = background_color)
		window.title(game_name)
		window.geometry(window_size)
		window.config(bg = background_color)
		window.iconbitmap(window_icon)
		thread7 = threading.Thread(target=update_square, daemon=True).start()
		thread = threading.Thread(target=update_label, daemon=True).start()
		thread2 = threading.Thread(target=update_circle, daemon=True).start()
		thread3 = threading.Thread(target=update_mask, daemon=True).start()
		thread4 = threading.Thread(target=press_hold, daemon=True).start()
		thread5 = threading.Thread(target=track_frames, daemon=True).start()
		thread6 = threading.Thread(target=update_conditions, daemon=True).start()
		thread8 = threading.Thread(target=update_shape, daemon=True).start()
		w, h = map(int,window_size.split("x"))
		canvas.pack()

		
		window.mainloop()
		
def on_press(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_press, window_icon, label,event_cancel
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	input_hold[k] = None
	if str(k) in input_vars_press:
		for ev in input_vars_press[str(k)]:
			evt = event_vars[ev]
			if len(evt) > 9:
				if evt[9] == "true":
					threading.Thread(target=events, args=(evt[0], evt), daemon=True).start()
				else:
					events(evt[0],evt)
			else:
				events(evt[0],evt)


				
def press_hold():
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_hold, window_icon, label,event_cancel
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in input_vars_hold:
			input_hold[k] = None
			if str(k) in input_active:
				for ev in input_vars_hold[str(k)]:
					evt = event_vars[ev]
					if event_cancel == False:
						if len(evt) > 5:
							if evt[5] == "true":
								event_cancel = True
						events(evt[0],evt)
def on_release(key):
	global game_name, window_size,background_color, game_vars, event_vars, input_vars_release, window_icon, label,event_cancel
	try:
		k = key.char
	except AttributeError:
		k = str(key)
	del input_hold[k]
	if str(k) in input_vars_release:
		for ev in input_vars_release[str(k)]:
			evt = event_vars[ev]
			if event_cancel == False:
				if len(evt) > 5:
					if evt[5] == "true":
						event_cancel = True
				events(evt[0],evt)
def update_mask():
	global game_masks
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for m in game_masks:
			nm = []+game_masks[m][2:]
			game_masks[m][0] = masks(game_masks[m][1],nm)
def update_conditions():
	while True:
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)

		for c in condition_events:
			bl = conditions(game_conditions[condition_events[c][0]][0],game_conditions[condition_events[c][0]][0:])

			if bl == True:
				for e in condition_events[c][1:]:
					events(event_vars[e][0],event_vars[e][0:])
		
def update_label(lp = None):
	global canvas
	lpdo = True
	while lpdo == True:
		if lp == "no":
			lpdo = False
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in label_data:
			if k in label_asset:
				x,y = canvas.coords(label_asset[k])
				if label_data[k][1] in ("string","str"):
					canvas.itemconfig(label_asset[k],text = label_data[k][0])
				elif label_data[k][1] in ("variable","var"):
					canvas.itemconfig(label_asset[k],text = game_vars[label_data[k][0]])
				elif label_data[k][1] in ("mask","msk"):
					canvas.itemconfig(label_asset[k],text = game_masks[label_data[k][0]][0])
				if label_data[k][3] in ("string","str"):
					canvas.coords(label_asset[k],int(label_data[k][2]),y)
				elif label_data[k][3] in ("variable","var"):
					canvas.coords(label_asset[k],game_vars[label_data[k][2]],y)
				elif label_data[k][3] in ("mask","msk"):
					canvas.coords(label_asset[k],game_masks[label_data[k][2]][0],y)
				x,y = canvas.coords(label_asset[k])
				if label_data[k][5] in ("string","str"):
					canvas.coords(label_asset[k],x,int(label_data[k][4]))
				elif label_data[k][5] in ("variable","var"):
					canvas.coords(label_asset[k],x,game_vars[label_data[k][4]])
				elif label_data[k][5] in ("mask","msk"):
					canvas.coords(label_asset[k],x,game_masks[label_data[k][4]][0])
				if label_data[k][7] in ("string","str"):
					canvas.itemconfig(label_asset[k],font = ("Arial",label_data[k][6]))
				elif label_data[k][7] in ("variable","var"):
					canvas.itemconfig(label_asset[k],font = ("Arial",game_vars[label_data[k][6]]))
				elif label_data[k][7] in ("mask","msk"):
					canvas.itemconfig(label_asset[k],font = ("Arial",game_masks[label_data[k][6]][0]))
			else:
				label_asset[k] = canvas.create_text(int(w)/2,int(h)/2, font=("Arial", 20))
def update_circle(lp = None):
	global canvas,circle_data,circle_asset
	lpdo = True
	while lpdo == True:
		if lp == "no":
			lpdo = False
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in list(circle_data.keys()):
			if k not in circle_asset:
				circle_asset[k] = canvas.create_oval(int(w)/2-50,int(h)/2-50,50+int(w)/2,50+int(w)/2, fill="#ffffff",outline="#000000")
			if circle_data[k][9] in ("string","str"):
				canvas.itemconfig(circle_asset[k],fill = circle_data[k][8])
			elif circle_data[k][9] in ("variable","var"):
				canvas.itemconfig(circle_asset[k],fill = game_vars[circle_data[k][8]])
			elif circle_data[k][9] in ("mask","msk"):
				canvas.itemconfig(circle_asset[k],fill = game_masks[circle_data[k][8]][0])
			if circle_data[k][11] in ("string","str"):
				canvas.itemconfig(circle_asset[k],outline = circle_data[k][10])
			elif circle_data[k][11] in ("variable","var"):
				canvas.itemconfig(circle_asset[k],fill = game_vars[circle_data[k][10]])
			elif circle_data[k][11] in ("mask","msk"):
				canvas.itemconfig(circle_asset[k],fill = game_masks[circle_data[k][10]][0])
			rx = 0
			ry = 0

			if circle_data[k][5] in ("string","str"):
				rx = circle_data[k][4]
			elif circle_data[k][5] in ("variable","var"):
				rx = game_vars[circle_data[k][4]]
			elif circle_data[k][5] in ("mask","msk"):
				rx = game_masks[circle_data[k][4]][0]
			if circle_data[k][7] in ("string","str"):
				ry = circle_data[k][6]
			elif circle_data[k][7] in ("variable","var"):
				ry = game_vars[circle_data[k][6]]
			elif circle_data[k][7] in ("mask","msk"):
				ry = game_masks[circle_data[k][6]][0]


			x,y = 0,0
			arrx, arry  = False, False
			if circle_data[k][1] in ("string","str"):
				x = circle_data[k][0]
			elif circle_data[k][1] in ("variable","var"):
				x = game_vars[circle_data[k][0]]
			elif circle_data[k][1] in ("mask","msk"):
				x = game_masks[circle_data[k][0]][0]
			elif circle_data[k][1] in ("array","arr"):
				x = game_arrs[circle_data[k][0]]
				arrx = True
			if circle_data[k][3] in ("string","str"):
				y = circle_data[k][2]
			elif circle_data[k][3] in ("variable","var"):
				y = game_vars[circle_data[k][2]]
			elif circle_data[k][3] in ("masks","msk"):
				y = game_masks[circle_data[k][2]][0]
			elif circle_data[k][3] in ("array","arr"):
				y = game_arrs[circle_data[k][0]]
				arry = True
			if arrx == False and arry == False:
				canvas.coords(circle_asset[k], x-rx, y-ry, x+rx, y+ry)
			else:
				if not isinstance(x, list):
					x = [x] * len(y)
				if not isinstance(y, list):
					y = [y] * len(x)
			    
				for nmb in range(len(x)):
					ox = x[nmb] - rx
					oy = y[nmb] - ry
					ox2 = x[nmb] + rx
					oy2 = y[nmb] + ry
					circle_name = f"{k}_{nmb}" if nmb > 0 else k
					if circle_name not in circle_asset:
						circle_asset[circle_name] = canvas.create_oval(ox, oy, ox2, oy2, fill=circle_data[k][8])
					else:
						canvas.coords(circle_asset[circle_name], ox, oy, ox2, oy2)
def update_square(lp = None):
	lpdo = True
	while lpdo == True:
		if lp == "no":
			lpdo = False
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)
		for k in list(square_data.keys()):
			if k not in square_asset:
				square_asset[k] = canvas.create_rectangle(50,50,150,150, fill="#ffffff",outline="#000000")
			if square_data[k][9] in ("string","str"):
				canvas.itemconfig(square_asset[k],fill = square_data[k][8])
			elif square_data[k][9] in ("variable","var"):
				canvas.itemconfig(square_asset[k],fill = game_vars[square_data[k][8]])
			elif square_data[k][9] in ("mask","msk"):
				canvas.itemconfig(square_asset[k],fill = game_masks[square_data[k][8]][0])
			if square_data[k][11] in ("string","str"):
				canvas.itemconfig(square_asset[k],outline = square_data[k][10])
			elif square_data[k][11] in ("variable","var"):
				canvas.itemconfig(square_asset[k],outline = game_vars[square_data[k][10]])
			elif square_data[k][11] in ("mask","msk"):
				canvas.itemconfig(square_asset[k],outline = game_masks[square_data[k][10]][0])
			rx = 0
			ry = 0

			if square_data[k][5] in ("string","str"):
				rx = int(square_data[k][4])
			elif square_data[k][5] in ("variable","var"):
				rx = game_vars[square_data[k][4]]
			elif square_data[k][5] in ("mask","msk"):
				rx = game_masks[square_data[k][4]][0]
			if square_data[k][7] in ("string","str"):
				ry = int(square_data[k][6])
			elif square_data[k][7] in ("variable","var"):
				ry = game_vars[square_data[k][6]]
			elif square_data[k][7] in ("mask","msk"):
				ry = game_masks[square_data[k][6]][0]


			x,y = 0,0
			arrx, arry  = False, False
			if square_data[k][1] in ("string","str"):
				x = int(square_data[k][0])
			elif square_data[k][1] in ("variable","var"):
				x = game_vars[square_data[k][0]]
			elif square_data[k][1] in ("mask","msk"):
				x = game_masks[square_data[k][0]][0]
			elif square_data[k][1] in ("array","arr"):
				x = game_arrs[square_data[k][0]]
				arrx = True
			if square_data[k][3] in ("string","str"):
				y = int(square_data[k][2])
			elif square_data[k][3] in ("variable","var"):
				y = game_vars[square_data[k][2]]
			elif square_data[k][3] in ("masks","msk"):
				y = game_masks[square_data[k][2]][0]
			elif square_data[k][3] in ("array","arr"):
				y = game_arrs[square_data[k][0]]
				arry = True
			if arrx == False and arry == False:
				canvas.coords(square_asset[k], x, y, rx, ry)
			else:
				if not isinstance(x, list):
					x = [x] * len(y)
				if not isinstance(y, list):
					y = [y] * len(x)
			    
				for nmb in range(len(x)):
					ox = x[nmb] - rx
					oy = y[nmb] - ry
					ox2 = x[nmb] + rx
					oy2 = y[nmb] + ry
					square_name = f"{k}_{nmb}" if nmb > 0 else k
					if square_name not in square_asset:
						square_asset[square_name] = canvas.create_oval(ox, oy, ox2, oy2, fill=square_data[k][8])
					else:
						canvas.coords(square_asset[square_name], ox, oy, ox2, oy2)


def update_shape(lp = None):
	lpdo = True
	while lpdo == True:
		if lp == "no":
			lpdo = False
		start = time.time()
		elapsed = time.time() - start
		sleep_time = ft - elapsed
		if sleep_time > 0:
			time.sleep(sleep_time)

		for k in shape_data:
			color = None
			border_color = None
			border = None
			if shape_config[k][3] in ("str","string"):
				color = shape_config[k][2]
			elif shape_config[k][3] in ("var","variable"):
				color = game_vars[shape_config[k][2]]
			elif shape_config[k][3] in ("mask","msk"):
				color = game_masks[shape_config[k][2]][0]
			if shape_config[k][5] in ("str","string"):
				border_color = shape_config[k][4]
			elif shape_config[k][5] in ("var","variable"):
				border_color = game_vars[shape_config[k][4]]
			elif shape_config[k][5] in ("mask","msk"):
				border_color = game_masks[shape_config[k][4]][0]
			if shape_config[k][7] in ("str","string"):
				border = shape_config[k][6]
			elif shape_config[k][7] in ("var","variable"):
				border = game_vars[shape_config[k][6]]
			elif shape_config[k][7] in ("mask","msk"):
				border = game_masks[shape_config[k][6]][0]

			try:
				border = float(border)
			except ValueError:
				border = int(border)


			pivot_x = None
			pivot_y = None
			points = []
			rotation = None

			if len(shape_data[k]) > 11:
				if shape_config[k][9] in ("str","string"):
					pivot_x = int(shape_config[k][8])
				elif shape_config[k][9] in ("var","variable"):
					pivot_x = game_vars[shape_config[k][8]]
				if shape_config[k][9] in ("msk","mask"):
					pivot_x = game_masks[shape_config[k][8]][0]
				if shape_config[k][11] in ("str","string"):
					pivot_y = int(shape_config[k][10])
				elif shape_config[k][11] in ("var","variable"):
					pivot_y = game_vars[shape_config[k][10]]
				elif shape_config[k][11] in ("msk","mask"):
					pivot_y = game_masks[shape_config[k][10]][0]



				for i in range(0,len(shape_data[k]),4):
					rel_x = None
					rel_y = None

					if shape_data[k][i+1] in ("str","string"):
						rel_x = int(shape_data[k][i]) - pivot_x
					elif shape_data[k][i+1] in ("var","variable"):
						rel_x = game_vars[shape_data[k][i]] - pivot_x
					elif shape_data[k][i+1] in ("mask","msk"):
						rel_x = game_masks[shape_data[k][i]][0] - pivot_x

					if shape_data[k][i+3] in ("str","string"):
						rel_y = int(shape_data[k][i+2]) - pivot_y
					elif shape_data[k][i+3] in ("var","variable"):
						rel_y = game_vars[shape_data[k][i+2]] - pivot_y
					elif shape_data[k][i+3] in ("mask","msk"):
						rel_y = game_masks[shape_data[k][i+2]][0] - pivot_y
					if shape_config[k][1] in ("str","string"):
						rotation = math.radians(int(shape_config[k][0]))
					elif shape_config[k][1] in ("var","variable"):
						rotation = math.radians(game_vars[shape_config[k][0]])
					elif shape_config[k][1] in ("mask","msk"):
						rotation = math.radians(game_masks[shape_config[k][0]][0])

					rot_x = pivot_x + rel_x * math.cos(rotation) - rel_y * math.sin(rotation)
					rot_y = pivot_y + rel_x * math.sin(rotation) + rel_y * math.cos(rotation)
					points.append(rot_x)
					points.append(rot_y)
			if k not in shape_asset:
				if len(shape_data[k]) > 11:
					shape_asset[k] = canvas.create_polygon(*points)
				else:
					shape_asset[k] = canvas.create_polygon(shape_config_default_points)



			else:
				if len(shape_data[k]) > 11:
					canvas.coords(shape_asset[k],*points)
					canvas.itemconfig(shape_asset[k],fill=color,outline =border_color, width = border)

			

			
			

def pre_press(key):

	try:
		k = key.char
	except AttributeError:
		k = str(key)
	input_active[k] = []

	threading.Thread(target = on_press,args=(key,)).start()
def pre_release(key):

	try:
		k = key.char
	except AttributeError:
		k = str(key)
	del input_active[k]

	threading.Thread(target = on_release,args=(key,)).start()

listener = keyboard.Listener(on_press=pre_press,on_release=pre_release)
listener.start()


main()